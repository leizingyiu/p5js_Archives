OPC.slider('ex', 0, 0, 5000, 1);
OPC.slider('ey', 0, 0, 5000, 1);
OPC.slider('ez', 100, 0, 5000, 1);
OPC.slider('cx', 0, 0, 5000, 1);
OPC.slider('cy', 0, 0, 5000, 1);
OPC.slider('cz', 0, 0, 5000, 1);
OPC.slider('ux', 0, 0, 1, 0.01);
OPC.slider('uy', 1, 0, 1, 0.01);
OPC.slider('uz', 0, 0, 1, 0.01);
OPC.slider('fr', -0.2, -1, 1, 0.01);
OPC.slider('near', 1, 0, 10, 0.01);
OPC.slider('far', 5000, 0, 50000, 10);

function setup() {
  createCanvas(windowWidth,windowHeight, WEBGL);
	cam=createCamera();	
}
function preload() {
  myFont = loadFont('https://fonts.cdnfonts.com/s/73830/GiganticFs-d9doR.woff');
}
function draw() {
		cam.camera(ex,ey,ez,
								cx,cy,cz,
								ux,uy,uz);
cam.frustum(fr, -fr, fr*(height/width), -fr*(height/width), near,far)
	
  background(0);
	
	noFill();
	stroke(255); 
	
	let rZ=radians(-rotationZ);
	let rY=radians(-rotationY);
	let rX=radians(-rotationX+PI);
	
	// let rx=radians(rotationX),ry=radians(rotationY),rz=radians(rotationZ);	
	// rz=rz>180?360-rz:rz;
	// let rZ=Math.cos(rx)*rz+Math.sin(rx)*ry;
	// let rY=Math.sin(rx)*rz+Math.cos(rx)*ry;
	// let rX=rx;
	
	// rotateX(PI);

	rotateZ(rZ);
	rotateX(rX);
	rotateY(rY);
  
	
	// translate(cx,cy,cz)
	// translate(mouseX/20, mouseX/20, mouseX/20)
	box(mouseX/10, mouseX/10, mouseX/10);
	
	

		noStroke();
		fill(255);
		textFont(myFont);
	let str=`${rotationX}_${rotationY}_${rotationZ}`.split('_').map(i=>Number(i).toFixed(2)).join(' ');
	let sW=textWidth(str);
		text(str,-sW/2,0);
}