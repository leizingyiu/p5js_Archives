var m=4,n=4,o=4;
var xd=40,yd=40,zd=40;
var boxR=15;
var noiseD=0.5;
var mousePressedBoo=false;
var rX=0,rY=0;
function setup() {
	createCanvas(windowWidth, windowHeight,WEBGL);
  
	vmin=Math.min(width,height);
	dmax=Math.max(m,n,o);
	d=4;
	
	xd=vmin/dmax/d;
	yd=vmin/dmax/d;
	zd=vmin/dmax/d;
	background(0);
	blendMode(LIGHTEST);
}

function mousePressed(){
		mousePressedBoo=true;
}
function mouseReleased(){
	mousePressedBoo=false;
}
function touchEnded(){
		mousePressedBoo=false;
}
function touchMoved(){
		mousePressedBoo=true;
}

function draw() {
	background(0);
	
	
	if(mousePressedBoo==true){
		
		rY+=(pmouseX-mouseX)/100;
		rX+=-(pmouseY-mouseY)/100;
		rotateY(rY);
	  rotateX(rX);
	}else{
		 rY+=noise(frameCount/10)/36;
		 rX+=noise(frameCount/10)/48;
		rY+=(pmouseX-mouseX)/1000;
		rX+=-(pmouseY-mouseY)/1000;
	  rotateY(rY);
	  rotateX(rX);
	}
	
	fill(0,20);
	stroke(255);
	strokeWeight(1);
	for(let i=-m;i<=m;i++){
		translate(i*xd,0,0);
		
		for(let j=-n;j<=n;j++){
			translate(0,j*yd,0);
			
			for(let k=-o;k<=o;k++){
				translate(0,0,-k*zd);
				let f =frameCount/40+1;
				let noiseK=noise(i*noiseD+f,j*noiseD+f,k*noiseD+f);
				strokeWeight(noiseK*2);
				stroke(noiseK*255/2+255/2);
				if(Math.abs(i)<m*0.6  &&
					 Math.abs(j)<n*0.6 &&
					 Math.abs(k)<o*0.6
					){
				box(noiseK*boxR*2);
				}else{
				sphere(noiseK*1.2);
				}
				translate(0,0,k*zd);
			}
			translate(0,-j*yd,0);
		}
		translate(-i*xd,0,0);
		
	}
	

	
	
	
	
}

class Cube{
	constructor(posx,posy,posz){
	}
}